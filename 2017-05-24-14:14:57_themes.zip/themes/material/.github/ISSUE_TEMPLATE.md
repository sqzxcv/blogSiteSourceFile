<!--
IF YOU DON'T FILL OUT THE FOLLOWING INFORMATION WE MIGHT CLOSE YOUR ISSUE WITHOUT INVESTIGATING
-->

**I certify that I have first consulted** (check all with "x")

- [ ] [Hexo documentation](https://hexo.io/docs/)
- [ ] [Material theme documentation](https://material.viosey.com/)
- [ ] [Material theme issues](https://github.com/viosey/hexo-theme-material/issues?utf8=%E2%9C%93&q=is%3Aissue)


**I'm submitting a**  (check one with "x")

- [ ] bug report
- [ ] feature request
- [ ] support request

<!-- ----------- -->
